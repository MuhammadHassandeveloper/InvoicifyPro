<tr id="country-<?php echo e($country->id); ?>">
    <td><?php echo e($country->name); ?></td>
    <td><?php echo e($country->iso_code); ?></td>
    <td><?php echo e($country->currency_sign); ?></td>
    <td><?php echo e($country->currency_code); ?></td>
    <td><?php echo e($country->created_at->format('d M Y ')); ?></td>
    <td>
        <span class="badge  p-2 <?php echo e($country->status ? 'badge-soft-success' : 'badge-soft-danger'); ?>">
            <?php echo e($country->status ? 'Active' : 'Disabled'); ?>

        </span>
    </td>
    <td>
        <button class="btn btn-soft-primary btn-sm" onclick="editCountry(<?php echo e($country->id); ?>)">
            <i class="las la-pen fs-17 align-middle"></i>
        </button>

        <button class="btn btn-soft-warning btn-sm d-inline-block" onclick="changeStatus(<?php echo e($country->id); ?>, <?php echo e($country->status ? 0 : 1); ?>)">
            <i class="las la-sync fs-17 align-middle"></i>
        </button>

        <button class="btn btn-soft-danger btn-sm" onclick="deleteCountry(<?php echo e($country->id); ?>)">
            <i class="las la-trash fs-17 align-middle"></i>
        </button>
    </td>
</tr>
<?php /**PATH E:\xampp\htdocs\MyProjects\StripeInvoicePro\resources\views/admin/countries/partials/country_row.blade.php ENDPATH**/ ?>