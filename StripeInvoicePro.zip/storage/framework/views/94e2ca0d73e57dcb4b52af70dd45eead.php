<header id="page-topbar">
    <div class="layout-width">
        <div class="navbar-header">
            <div class="d-flex">
                <!-- LOGO -->




















                <button type="button" class="btn btn-sm px-3 fs-16 header-item vertical-menu-btn topnav-hamburger" id="topnav-hamburger-icon">
                    <span class="hamburger-icon">
                        <span></span>
                        <span></span>
                        <span></span>
                    </span>
                </button>


            </div>

            <div class="d-flex align-items-center">



                <div class="ms-1 header-item d-none d-sm-flex">
                    <button type="button" class="btn btn-icon btn-topbar btn-ghost-primary rounded-circle" data-toggle="fullscreen">
                        <i class='las la-expand fs-24'></i>
                    </button>
                </div>

                <div class="ms-1 header-item d-none d-sm-flex">
                    <button type="button" class="btn btn-icon btn-topbar btn-ghost-primary rounded-circle light-dark-mode">
                        <i class='las la-moon fs-24'></i>
                    </button>
                </div>

                <div class="dropdown header-item">
                    <button type="button" class="btn" id="page-header-user-dropdown" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="d-flex align-items-center">
                            <img class="rounded-circle header-profile-user" src="<?php echo e(asset('assets/images/users/avatar-4.jpg')); ?>" alt="Header Avatar">
                            <span class="text-start ms-xl-2">
                                <span class="d-none d-xl-inline-block fw-medium user-name-text fs-16">
                                    <?php echo e(Sentinel::getUser()->first_name); ?>  <?php echo e(Sentinel::getUser()->last_name); ?>

                                    <i class="las la-angle-down fs-12 ms-1"></i>
                                </span>
                            </span>
                        </span>
                    </button>
                    <div class="dropdown-menu dropdown-menu-end">
                        <!-- item-->
                        <a class="dropdown-item" href="<?php echo e(route('accountant.profile.setting')); ?>"><i class="bx bx-user fs-15 align-middle me-1"></i> <span key="t-profile">Profile</span></a>

                        <a class="dropdown-item text-danger" href="<?php echo e(url('logout')); ?>">
                            <i class="bx bx-power-off fs-15 align-middle me-1 text-danger"></i>
                            <span key="t-logout">Logout</span></a>

                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH E:\xampp\htdocs\MyProjects\StripeInvoicePro\resources\views/accountant/layout/header.blade.php ENDPATH**/ ?>