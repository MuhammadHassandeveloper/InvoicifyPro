<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid mt-2 mb-3">
            <div class="row">
                <div class="col-12">
                    
                    <form action="" method="GET" class="mb-4">
                        <div class="row">
                            <div class="col-md-3">
                                <input type="date" name="from_date" value="<?php echo e($fromDate); ?>" class="form-control" placeholder="From Date">
                            </div>
                            <div class="col-md-3">
                                <input type="date" name="to_date" value="<?php echo e($toDate); ?>" class="form-control" placeholder="To Date">
                            </div>
                            <div class="col-md-3">
                                <button type="submit" class="btn btn-primary">Filter</button>
                            </div>
                        </div>
                    </form>

                    
                    <div class="list-group">
                        <?php $__currentLoopData = $activityLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="javascript:void(0);" class="list-group-item list-group-item-action mb-2 p-4">
                                <div class="float-end fw-bold fs-18">
                                    <?php echo e(ucfirst($log->action)); ?>

                                </div>
                                <div class="d-flex mb-2 align-items-center">
                                    <div class="flex-grow-1 ms-3">
                                        <h5 class="list-title fs-15 mb-1">
                                            <strong>User:</strong>
                                            <?php echo e($log->user->first_name); ?> <?php echo e($log->user->last_name); ?>

                                        </h5>
                                        <p class="list-text mb-0 fs-12"><?php echo e($log->created_at->diffForHumans()); ?></p>
                                    </div>
                                </div>
                                <p class="list-text mb-0">
                                    <?php if(is_array($log->details)): ?>
                                        <?php $__currentLoopData = $log->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <strong><?php echo e(ucfirst($key)); ?>:</strong>
                                            <?php if(is_array($value)): ?>
                                                <?php echo e(implode(', ', $value)); ?>

                                            <?php else: ?>
                                                <?php echo e(htmlspecialchars($value)); ?>

                                            <?php endif; ?>
                                            <br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <?php echo e(htmlspecialchars($log->details)); ?>

                                    <?php endif; ?>
                                </p>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\MyProjects\StripeInvoicePro\resources\views/admin/acitivitylogs.blade.php ENDPATH**/ ?>