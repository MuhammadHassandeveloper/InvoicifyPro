<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('products-dropdown','active'); ?>
<?php $__env->startSection('products-dropdown-show','show'); ?>
<?php $__env->startSection('product-list-page','active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-3">
               <h4 class="ml-3"><b><?php echo e($title); ?></b></h4>
                <a href="<?php echo e(route('accountant.products.index')); ?>" class="btn btn-secondary">Back to Products</a>
            </div>

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <form id="edit-product-form" class="needs-validation was-validated"
                                  action="<?php echo e(route('accountant.products.update', $product->id)); ?>" method="post"
                                  enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="product_name">Product Name<span class="text-danger">*</span></label>
                                            <input id="product_name" maxlength="40" max="40" name="product_name" placeholder="Enter Product Name" type="text" class="form-control" value="<?php echo e($product->name); ?>" required="">
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="available_stock">Stock<span class="text-danger">*</span></label>
                                            <input type="number" id="available_stock" name="available_stock" placeholder="Enter Stock" class="form-control" value="<?php echo e($product->available_stock); ?>" required="">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="edit-brand">Brand</label>
                                            <select class="form-control" id="edit-brand" name="brand" required>
                                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($brand->id); ?>" <?php echo e($brand->id == $product->brand_id ? 'selected' : ''); ?>><?php echo e($brand->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="edit-category">Category</label>
                                            <select class="form-control" id="edit-category" name="category" required>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        value="<?php echo e($category->id); ?>" <?php echo e($category->id == $product->category_id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="edit-price">Price</label>
                                            <input type="number" class="form-control" id="edit-price" name="price"
                                                   value="<?php echo e($product->price); ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label for="edit-image">Image</label>
                                            <input type="file" class="form-control" id="edit-image"
                                                   name="product_image">
                                            <?php if($product->image): ?>
                                                <img src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->name); ?>" class="img-thumbnail mt-2" width="150">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group mb-3">
                                    <label for="edit-description">Description</label>
                                    <textarea class="form-control" max="150" maxlength="150" id="edit-description" name="product_description"
                                              required><?php echo e($product->description); ?></textarea>
                                </div>
                                <div class="form-group mb-3">
                                    <button type="submit" class="btn btn-primary">Save Changes</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
        var forms = document.querySelectorAll('form');
        forms.forEach(function (form) {
            form.addEventListener('submit', function (event) {
                event.preventDefault();
                var submitButton = form.querySelector('button[type="submit"]');
                var originalText = submitButton.innerText; // Store the original text
                var $button = $(submitButton);
                $($button).html(`
                    <span class="text-light">processing...</span>
                    <span class="text-end text-light spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>`
                );
                submitButton.disabled = true;
                setTimeout(function () {
                    form.submit();
                }, 1000);
                setTimeout(function () {
                    $($button).html(originalText);
                    submitButton.disabled = false;
                }, 3000);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('accountant.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\MyProjects\StripeInvoicePro\resources\views/accountant/products/edit.blade.php ENDPATH**/ ?>