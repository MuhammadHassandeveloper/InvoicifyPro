
<tr id="tax-<?php echo e($tax->id); ?>">
    <td><?php echo e($tax->country->name); ?></td>
    <td><?php echo e($tax->name); ?></td>
    <td><?php echo e($tax->percentage); ?>%</td>
    <td><?php echo e($tax->created_at->format('d M Y ')); ?></td>
    <td><?php echo e($tax->user->first_name); ?> <?php echo e($tax->user->last_name); ?></td>

    <td>
            <span class="badge  p-2 <?php echo e($tax->status ? 'badge-soft-success' : 'badge-soft-danger'); ?>">
                <?php echo e($tax->status ? 'Active' : 'Disabled'); ?>

            </span>
    </td>

    <td>
        <button class="btn btn-soft-primary btn-sm" onclick="editTax(<?php echo e($tax->id); ?>)">
            <i class="las la-pen fs-17 align-middle"></i>
        </button>
        <button class="btn btn-soft-warning btn-sm d-inline-block" onclick="changeStatus(<?php echo e($tax->id); ?>, <?php echo e($tax->status ? 0 : 1); ?>)">
            <i class="las la-sync fs-17 align-middle"></i>
        </button>
        <button class="btn btn-soft-danger btn-sm" onclick="deleteTax(<?php echo e($tax->id); ?>)">
            <i class="las la-trash fs-17 align-middle"></i>
        </button>
    </td>
</tr>
<?php /**PATH E:\xampp\htdocs\MyProjects\StripeInvoicePro\resources\views/admin/taxes/partials/tax_row.blade.php ENDPATH**/ ?>