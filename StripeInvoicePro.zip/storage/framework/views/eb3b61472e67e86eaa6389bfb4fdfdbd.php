<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> © <?php echo e(App\Helpers\AppHelper::site_name()); ?>.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Design & Develop by <?php echo e(App\Helpers\AppHelper::develop_by()); ?>

                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH E:\xampp\htdocs\MyProjects\StripeInvoicePro\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>