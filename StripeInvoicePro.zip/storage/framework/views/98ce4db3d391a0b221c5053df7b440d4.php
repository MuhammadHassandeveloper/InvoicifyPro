<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('clients-dropdown','active'); ?>
<?php $__env->startSection('clients-dropdown-show','show'); ?>
<?php $__env->startSection('client-list-page','active'); ?>
<?php $__env->startSection('client-active-list-page','active'); ?>
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Start Page-content -->
    <div class="page-content">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="ml-3"><b><?php echo e($title); ?></b></h4>
                <a href="<?php echo e(route('admin.clients.create')); ?>" class="btn btn-primary" >Create Client</a>
            </div>

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-tabs nav-tabs-custom nav-success mb-3" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link <?php echo $__env->yieldContent('client-all-list-page'); ?>" href="<?php echo e(route('admin.clients.index')); ?>" role="tab" aria-selected="true">
                                        All
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link <?php echo $__env->yieldContent('active-client-list-page'); ?>" href="<?php echo e(route('admin.clients.active')); ?>" role="tab" aria-selected="false">
                                        Active
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo $__env->yieldContent('disabled-client-list-page'); ?>" href="<?php echo e(route('admin.clients.disabled')); ?>" role="tab" aria-selected="false">
                                        Disabled
                                    </a>
                                </li>


                            </ul>

                            <div class="table-card">
                                <table id="DataTables_Table_0" class="table nowrap dt-responsive align-middle table-hover table-bordered mb-0 dataTable no-footer dtr-inline collapsed">
                                    <thead class="table-light">
                                    <tr>
                                        <th>Client Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Created At</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody id="client-table-body">
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="client-<?php echo e($client->id); ?>">
                                            <td>
                                                <a href="<?php echo e(route('admin.clients.edit',$client->id)); ?>" class="text-body align-middle fw-medium"><?php echo e($client->first_name); ?> <?php echo e($client->last_name); ?></a>
                                            </td>
                                            <td><?php echo e($client->email); ?></td>
                                            <td><?php echo e($client->phone); ?></td>
                                            <td><?php echo e($client->created_at->format('d M Y ')); ?></td>
                                            <td>
                                                <span class="badge p-2 <?php echo e($client->status ? 'badge-soft-success' : 'badge-soft-danger'); ?>">
                                                    <?php echo e($client->status ? 'Active' : 'Inactive'); ?>

                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn btn-soft-info btn-sm" onclick="viewClient(<?php echo e($client->id); ?>)">
                                                    <i class="las la-eye fs-17 align-middle"></i>
                                                </button>

                                                <a href="<?php echo e(route('admin.clients.edit',$client->id)); ?>" class="btn btn-soft-primary btn-sm">
                                                    <i class="las la-pen fs-17 align-middle"></i>
                                                </a>

                                                <button class="btn btn-soft-warning btn-sm d-inline-block" onclick="changeStatus(<?php echo e($client->id); ?>)">
                                                    <i class="las la-sync fs-17 align-middle"></i>
                                                </button>

                                                <button class="btn btn-soft-danger btn-sm" onclick="deleteClient(<?php echo e($client->id); ?>)">
                                                    <i class="las la-trash fs-17 align-middle"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="clientModal" tabindex="-1" role="dialog" aria-labelledby="clientModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="clientModalLabel">Client Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <!-- Billing Details -->
                    <div class="card card-light">
                        <div class="card-body">
                            <div class="card-header">
                                <h5 class="card-title fw-bold">
                                    Billing Details
                                </h5>
                                <div class="row mb-2">
                                    <div class="col-6 font-weight-bold">Billing Address:</div>
                                    <div class="col-6" id="clientBillingAddress"></div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-6 font-weight-bold">Billing City:</div>
                                    <div class="col-6" id="clientBillingCity"></div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-6 font-weight-bold">Billing State:</div>
                                    <div class="col-6" id="clientBillingState"></div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-6 font-weight-bold">Billing Phone:</div>
                                    <div class="col-6" id="clientBillingZip"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Shipping Details -->
                    <div class="card card-light">
                        <div class="card-body">
                            <div class="card-header">
                                <h5 class="card-title fw-bold">
                                    Shipping Details
                                </h5>
                                <div class="row mb-2">
                                    <div class="col-6 font-weight-bold">Shipping Address:</div>
                                    <div class="col-6" id="clientShippingAddress"></div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-6 font-weight-bold">Shipping City:</div>
                                    <div class="col-6" id="clientShippingCity"></div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-6 font-weight-bold">Shipping State:</div>
                                    <div class="col-6" id="clientShippingState"></div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-6 font-weight-bold">Shipping Phone:</div>
                                    <div class="col-6" id="clientShippingZip"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function deleteClient(clientId) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: "/admin/clients/destroy/" + clientId,
                        type: 'GET',
                        data: {
                            "_token": "<?php echo e(csrf_token()); ?>"
                        },
                        success: function(response) {
                            $('#client-' + clientId).remove();
                            Swal.fire({
                                icon: 'success',
                                text: 'Client has been deleted successfully!',
                            });
                        },
                        error: function() {
                            Swal.fire({
                                icon: 'error',
                                text: 'Something went wrong. Please try again.',
                            });
                        }
                    });
                }
            });
        }

        function changeStatus(clientId) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, change it!',
                cancelButtonText: 'Cancel',
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: "/admin/clients/status/" + clientId,
                        type: 'post',
                        data: {
                            "_token": "<?php echo e(csrf_token()); ?>"
                        },
                        success: function(response) {
                            Swal.fire({
                                icon: 'success',
                                text: 'Client status has been updated successfully!',
                            });
                            setTimeout(function() {
                                window.location.reload();
                            }, 2000);
                        },
                        error: function() {
                            Swal.fire({
                                icon: 'error',
                                text: 'Something went wrong. Please try again.',
                            });
                        }
                    });
                }
            });
        }

        function viewClient(clientId) {
            $.ajax({
                url: "/admin/clients/show/" + clientId,
                type: 'GET',
                success: function(response) {
                    $('#clientName').text(response.client.name);
                    $('#clientEmail').text(response.client.email);
                    $('#clientPhone').text(response.client.phone);

                    // Billing Details
                    $('#clientBillingAddress').text(response.client.billing_address);
                    $('#clientBillingCity').text(response.client.billing_city);
                    $('#clientBillingState').text(response.client.billing_state);
                    $('#clientBillingZip').text(response.client.billing_phone);

                    // Shipping Details
                    $('#clientShippingAddress').text(response.client.shipping_address);
                    $('#clientShippingCity').text(response.client.shipping_city);
                    $('#clientShippingState').text(response.client.shipping_state);
                    $('#clientShippingZip').text(response.client.shipping_phone);
                    $('#clientModal').modal('show');
                },
                error: function() {
                    Swal.fire({
                        icon: 'error',
                        text: 'Something went wrong. Please try again.',
                    });
                }
            });
        }



    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\MyProjects\StripeInvoicePro\resources\views/admin/clients/active.blade.php ENDPATH**/ ?>