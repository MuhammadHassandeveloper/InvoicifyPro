<tr id="shipping-charge-<?php echo e($shippingCharge->id); ?>">
    <td><?php echo e($shippingCharge->country->name); ?></td>
    <td><?php echo e($shippingCharge->name); ?></td>
    <td><?php echo e($shippingCharge->percentage); ?>%</td>
    <td><?php echo e($shippingCharge->created_at->format('d M Y ')); ?></td>
    <td><?php echo e($shippingCharge->user->first_name); ?> <?php echo e($shippingCharge->user->last_name); ?></td>
    <td>
        <span class="badge  p-2 <?php echo e($shippingCharge->status ? 'badge-soft-success' : 'badge-soft-danger'); ?>">
            <?php echo e($shippingCharge->status ? 'Active' : 'Disabled'); ?>

        </span>
    </td>
    <td>
        <button class="btn btn-soft-primary btn-sm" onclick="editShippingCharge(<?php echo e($shippingCharge->id); ?>)">
            <i class="las la-pen fs-17 align-middle"></i>
        </button>

        <button class="btn btn-soft-warning btn-sm d-inline-block" onclick="changeStatus(<?php echo e($shippingCharge->id); ?>, <?php echo e($shippingCharge->status ? 0 : 1); ?>)">
            <i class="las la-sync fs-17 align-middle"></i>
        </button>

        <button class="btn btn-soft-danger btn-sm" onclick="deleteShippingCharge(<?php echo e($shippingCharge->id); ?>)">
            <i class="las la-trash fs-17 align-middle"></i>
        </button>
    </td>
</tr>
<?php /**PATH E:\xampp\htdocs\MyProjects\StripeInvoicePro\resources\views/admin/shipping_charges/partials/shipping_charge_row.blade.php ENDPATH**/ ?>