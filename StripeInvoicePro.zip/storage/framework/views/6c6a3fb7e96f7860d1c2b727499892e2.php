<tr id="discount-<?php echo e($discount->id); ?>">
    <td><?php echo e($discount->name); ?></td>
    <td><?php echo e($discount->percentage); ?>%</td>
    <td><?php echo e($discount->created_at->format('d M Y ')); ?></td>
    <td><?php echo e($discount->user->first_name); ?> <?php echo e($discount->user->last_name); ?></td>
    <td>
            <span class="badge  p-2 <?php echo e($discount->status ? 'badge-soft-success' : 'badge-soft-danger'); ?>">
                <?php echo e($discount->status ? 'Active' : 'Disabled'); ?>

            </span>
    </td>
    <td>
        <button class="btn btn-soft-primary btn-sm" onclick="editDiscount(<?php echo e($discount->id); ?>)">
            <i class="las la-pen fs-17 align-middle"></i>
        </button>

        <button class="btn btn-soft-warning btn-sm d-inline-block" onclick="changeStatus(<?php echo e($discount->id); ?>, <?php echo e($discount->status ? 0 : 1); ?>)">
            <i class="las la-sync fs-17 align-middle"></i>
        </button>

        <button class="btn btn-soft-danger btn-sm" onclick="deleteDiscount(<?php echo e($discount->id); ?>)">
            <i class="las la-trash fs-17 align-middle"></i>
        </button>
    </td>
</tr>
<?php /**PATH E:\xampp\htdocs\MyProjects\StripeInvoicePro\resources\views/accountant/discounts/partials/discount_row.blade.php ENDPATH**/ ?>