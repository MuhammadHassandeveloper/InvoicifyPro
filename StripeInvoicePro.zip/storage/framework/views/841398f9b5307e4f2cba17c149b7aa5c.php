<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('invoices-dropdown','active'); ?>
<?php $__env->startSection('invoices-dropdown-show','show'); ?>
<?php $__env->startSection('paid-invoices-list-page','active'); ?>
<?php $__env->startSection('invoices-list-page','active'); ?>
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Start Page-content -->
    <div class="page-content">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="ml-3"><b><?php echo e($title); ?></b></h4>
                <span class="badge p-2   text-bg-warning">
                    Paid
                </span>
            </div>

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-tabs nav-tabs-custom nav-success mb-3" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link <?php echo $__env->yieldContent('invoices-list-page'); ?>" href="<?php echo e(url('/admin/invoices')); ?>" role="tab" aria-selected="true">
                                        All
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link <?php echo $__env->yieldContent('unpaid-invoices-list-page'); ?>" href="<?php echo e(url('/admin/invoices/unpaid')); ?>" role="tab" aria-selected="false">
                                        UnPaid
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo $__env->yieldContent('paid-invoices-list-page'); ?>" href="<?php echo e(url('/admin/invoices/paid')); ?>" role="tab" aria-selected="false">
                                        Paid
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link <?php echo $__env->yieldContent('void-invoices-list-page'); ?>" href="<?php echo e(url('/admin/invoices/void')); ?>" role="tab" aria-selected="false">
                                        Void
                                    </a>
                                </li>

                            </ul>

                            <div class="table-card">
                                <table id="DataTables_Table_0" class="table nowrap dt-responsive align-middle table-hover table-bordered mb-0 dataTable no-footer dtr-inline collapsed">
                                    <thead class="table-light">
                                <tr>
                                    <th>Invoice Number</th>
                                    <th>Customer</th>
                                    <th>Amount Due</th>
                                    <th>Created At</th>
                                    <th>Due Date</th>
                                    <th>Paid Date</th>
                                    <th>Payment Link</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tbody id="invoice-table-body">
                                <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                           $invoice_paid_date = $invoice->invoice_paid_date;
                                           $invoice_paid_time = $invoice->invoice_paid_time;
                                           $invoice_paid_date = \DateTime::createFromFormat('Y-m-d', $invoice_paid_date);
                                           $invoice_paid_time = \DateTime::createFromFormat('H:i:s', $invoice_paid_time);
                                           $paid_date_time = $invoice_paid_date->format('d M Y') . ' ' . $invoice_paid_time->format('g:i A');
                                    ?>
                                    <tr id="invoice-<?php echo e($invoice->id); ?>">
                                        <td>
                                            <a href="<?php echo e(route('admin.invoices.show', $invoice->id)); ?>" class="text-body align-middle fw-medium"><?php echo e($invoice->stripe_invoice_number); ?></a>
                                        </td>

                                        <td>
                                            <?php echo e($invoice->customer->first_name. ' ' .$invoice->customer->last_name ?? 'N/A'); ?>

                                            <br>
                                            <?php echo e($invoice->customer->phone); ?>

                                            <span class="badge text-bg-warning">
                                                (<?php echo e($invoice->customer->country->iso_code); ?>)
                                            </span>

                                        </td>
                                        <td>
                                            <span class="badge text-bg-dark">
                                                <?php echo e(App\Helpers\AppHelper::appCurrencySign()); ?><?php echo e(number_format($invoice->amount, 2)); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e($invoice->created_at->format('d M Y')); ?></td>
                                        <td><?php echo e(date('d M Y',strtotime($invoice->period_end ))); ?></td>
                                        <td><?php echo e($paid_date_time); ?> </td>

                                        <td>
                                            <?php if($invoice->status != 'void'): ?>
                                                <span style="cursor: pointer; padding: 6px;" class="badge badge-soft-primary sharePaymentLink" data-link="<?php echo e($invoice->stripe_invoice_url); ?>">Copy Now</span>
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <a href="<?php echo e(route('admin.invoices.show', $invoice->id)); ?>" class="btn btn-soft-info btn-sm" >
                                                <i class="las la-eye fs-17 align-middle"></i>
                                            </a>

                                            <a href="<?php echo e($invoice->stripe_invoice_pdf_url); ?>" class="btn btn-soft-warning btn-sm">
                                                <i class="la la-download fs-17 align-middle"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        var shareButtons = document.getElementsByClassName('sharePaymentLink');

        for (var i = 0; i < shareButtons.length; i++) {
            shareButtons[i].addEventListener('click', function() {
                var currentUrl = this.getAttribute('data-link');
                var tempInput = document.createElement('input');
                tempInput.setAttribute('type', 'text');
                tempInput.setAttribute('value', currentUrl);
                document.body.appendChild(tempInput);
                tempInput.select();
                document.execCommand('copy');
                document.body.removeChild(tempInput);
                this.innerText = 'Copied!';
                var that = this;
                setTimeout(function() {
                    that.innerText = 'Copy Now';
                }, 1000);
            });
        }
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\MyProjects\StripeInvoicePro\resources\views/admin/invoices/paid.blade.php ENDPATH**/ ?>