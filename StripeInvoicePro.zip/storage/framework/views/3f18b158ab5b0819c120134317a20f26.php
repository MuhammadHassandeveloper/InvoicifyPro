<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('accountant-list-page', 'active'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Start Page-content -->
    <div class="page-content">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="ml-3"><b><?php echo e($title); ?></b></h4>
                <a href="<?php echo e(route('admin.accountants.create')); ?>" class="btn btn-primary">Create Accountant</a>
            </div>

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-card">
                                    <table id="DataTables_Table_0" class="table nowrap dt-responsive align-middle table-hover table-bordered mb-0 dataTable no-footer dtr-inline collapsed">
                                        <thead class="table-light">
                                        <tr>
                                            <th>Full Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Country</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $accountants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accountant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($accountant->first_name); ?> <?php echo e($accountant->last_name); ?></td>
                                                <td><?php echo e($accountant->email); ?></td>
                                                <td><?php echo e($accountant->phone); ?></td>
                                                <td><?php echo e($accountant->country->name); ?></td>
                                                <td>
                                                <span class="badge p-2 <?php echo e($accountant->status ? 'badge-soft-success' : 'badge-soft-danger'); ?>">
                                                    <?php echo e($accountant->status ? 'Active' : 'Inactive'); ?>

                                                </span>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('admin.accountants.edit', $accountant->id)); ?>" class="btn btn-soft-primary btn-sm">
                                                        <i class="las la-pen fs-17 align-middle"></i>
                                                    </a>

                                                    <button class="btn btn-soft-warning btn-sm d-inline-block" onclick="changeStatus(<?php echo e($accountant->id); ?>)">
                                                        <i class="las la-sync fs-17 align-middle"></i>
                                                    </button>

                                                    <button class="btn btn-soft-danger btn-sm" onclick="deleteAccountant(<?php echo e($accountant->id); ?>)">
                                                        <i class="las la-trash fs-17 align-middle"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function deleteAccountant(id) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '/admin/accountants/destroy/' + id,
                        type: 'DELETE',
                        data: {
                            "_token": "<?php echo e(csrf_token()); ?>"
                        },
                        success: function() {
                            location.reload();
                        },
                        error: function() {
                            Swal.fire({
                                icon: 'error',
                                text: 'Something went wrong. Please try again.',
                            });
                        }
                    });
                }
            });
        }

        function changeStatus(clientId) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, change it!',
                cancelButtonText: 'Cancel',
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '/admin/accountants/status/' + clientId,
                        type: 'post',
                        data: {
                            "_token": "<?php echo e(csrf_token()); ?>"
                        },
                        success: function(response) {
                            Swal.fire({
                                icon: 'success',
                                text: 'Accountant status has been updated successfully!',
                            });
                            setTimeout(function() {
                                window.location.reload();
                            }, 2000);
                        },
                        error: function() {
                            Swal.fire({
                                icon: 'error',
                                text: 'Something went wrong. Please try again.',
                            });
                        }
                    });
                }
            });
        }


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\MyProjects\StripeInvoicePro\resources\views/admin/accountants/index.blade.php ENDPATH**/ ?>