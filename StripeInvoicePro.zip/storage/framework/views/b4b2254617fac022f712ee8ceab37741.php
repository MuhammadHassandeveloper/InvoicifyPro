<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('taxes-discounts-dropdown','active'); ?>
<?php $__env->startSection('taxes-discounts-dropdown-show','show'); ?>
<?php $__env->startSection('taxes-page','active'); ?>
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Start Page-content -->
    <div class="page-content">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-3">
               <h4 class="ml-3"><b><?php echo e($title); ?></b></h4>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createTaxModal">Create Tax</button>
            </div>

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-card">
                                <table id="DataTables_Table_0" class="table nowrap dt-responsive align-middle table-hover table-bordered mb-0 dataTable no-footer dtr-inline collapsed">
                                    <thead class="table-light">
                                    <tr>
                                        <th>Country</th>
                                        <th>Tax Name</th>
                                        <th>Percentage</th>
                                        <th>Created At</th>
                                        <th>Created By</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody id="tax-table-body">
                                    <?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="tax-<?php echo e($tax->id); ?>">
                                            <td><?php echo e($tax->country->name); ?></td>
                                            <td><?php echo e($tax->name); ?></td>
                                            <td><?php echo e($tax->percentage); ?>%</td>
                                            <td><?php echo e($tax->created_at->format('d M Y ')); ?></td>
                                            <td><?php echo e($tax->user->first_name); ?> <?php echo e($tax->user->last_name); ?></td>
                                            <td>
                                                <span class="badge  p-2 <?php echo e($tax->status ? 'badge-soft-success' : 'badge-soft-danger'); ?>">
                                                    <?php echo e($tax->status ? 'Active' : 'Disabled'); ?>

                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn btn-soft-primary btn-sm" onclick="editTax(<?php echo e($tax->id); ?>)">
                                                    <i class="las la-pen fs-17 align-middle"></i>
                                                </button>
                                                <button class="btn btn-soft-warning btn-sm d-inline-block" onclick="changeStatus(<?php echo e($tax->id); ?>, <?php echo e($tax->status ? 0 : 1); ?>)">
                                                    <i class="las la-sync fs-17 align-middle"></i>
                                                </button>
                                                <button class="btn btn-soft-danger btn-sm" onclick="deleteTax(<?php echo e($tax->id); ?>)">
                                                    <i class="las la-trash fs-17 align-middle"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Create Tax Modal -->
    <div class="modal fade" id="createTaxModal" tabindex="-1" role="dialog" aria-labelledby="createTaxModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content border-0">
                <form id="create-tax-form" method="post" class="needs-validation was-validated">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="createTaxModalLabel">Create Tax</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="create-country_id">Country</label>
                            <select class="form-control" id="create-country_id" name="country_id" required>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="create-name">Name</label>
                            <input type="text" class="form-control" id="create-name" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="create-percentage">Percentage</label>
                            <input type="text" class="form-control" id="create-percentage" name="percentage" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save Tax</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Tax Modal -->
    <div class="modal fade" id="editTaxModal" tabindex="-1" role="dialog" aria-labelledby="editTaxModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content border-0">
                <form id="edit-tax-form" class="needs-validation was-validated">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="editTaxModalLabel">Edit Tax</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="edit-tax_id" name="tax_id">
                        <div class="form-group">
                            <label for="edit-country_id">Country</label>
                            <select class="form-control" id="edit-country_id" name="country_id" required>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="edit-name">Name</label>
                            <input type="text" class="form-control" id="edit-name" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="edit-percentage">Percentage</label>
                            <input type="text" class="form-control" id="edit-percentage" name="percentage" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            // Handle form submission for create tax
            $('#create-tax-form').on('submit', function(e) {
                e.preventDefault();
                let formData = $(this).serialize();
                $.ajax({
                    url: "<?php echo e(route('accountant.taxes.store')); ?>",
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        $('#tax-table-body').append(response);
                        $('#createTaxModal').modal('hide');
                        $('#create-tax-form')[0].reset();
                        Swal.fire({
                            icon: 'success',
                            text: 'Tax has been created successfully!',
                        });
                    },
                    error: function(xhr) {
                        if (xhr.status === 422) {
                            let errors = xhr.responseJSON.errors;
                            let errorMessage = '';
                            for (let key in errors) {
                                errorMessage += errors[key][0] + '<br>';
                            }
                            Swal.fire({
                                icon: 'error',
                                html: errorMessage,
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                text: 'Something went wrong. Please try again.',
                            });
                        }
                    }
                });
            });

            // Handle form submission for edit tax
            $('#edit-tax-form').on('submit', function(e) {
                e.preventDefault();
                let formData = $(this).serialize();
                let taxId = $('#edit-tax_id').val();

                $.ajax({
                    url: "<?php echo e(route('accountant.taxes.update', '')); ?>/" + taxId,
                    type: 'POST',
                    data: formData,
                    headers: {
                        'X-HTTP-Method-Override': 'PUT'
                    },
                    success: function(response) {
                        $('#tax-' + taxId).replaceWith(response);
                        $('#editTaxModal').modal('hide');
                        $('#edit-tax-form')[0].reset();
                        Swal.fire({
                            icon: 'success',
                            text: 'Tax has been updated successfully!',
                        });
                    },
                    error: function(xhr) {
                        if (xhr.status === 422) {
                            let errors = xhr.responseJSON.errors;
                            let errorMessage = '';
                            for (let key in errors) {
                                errorMessage += errors[key][0] + '<br>';
                            }
                            Swal.fire({
                                icon: 'error',
                                html: errorMessage,
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                text: 'Something went wrong. Please try again.',
                            });
                        }
                    }
                });
            });
        });

        function editTax(id) {
            $.ajax({
                url: "<?php echo e(route('accountant.taxes.show', '')); ?>/" + id,
                type: 'GET',
                success: function(response) {
                    $('#editTaxModalLabel').text('Edit Tax');
                    $('#edit-tax_id').val(response.id);
                    $('#edit-country_id').val(response.country_id);
                    $('#edit-name').val(response.name);
                    $('#edit-percentage').val(response.percentage);
                    $('#editTaxModal').modal('show');
                },
                error: function(xhr) {
                    Swal.fire({
                        icon: 'error',
                        text: 'Something went wrong. Please try again.',
                    });
                }
            });
        }

        function deleteTax(id) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ffaa33',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: "<?php echo e(route('accountant.taxes.destroy', '')); ?>/" + id,
                        type: 'DELETE',
                        data: {
                            "_token": "<?php echo e(csrf_token()); ?>"
                        },
                        success: function(response) {
                            $('#tax-' + id).remove();
                            Swal.fire(
                                'Deleted!',
                                'Tax has been deleted.',
                                'success'
                            );
                        },
                        error: function(xhr) {
                            Swal.fire({
                                icon: 'error',
                                text: 'Something went wrong. Please try again.',
                            });
                        }
                    });
                }
            });
        }

        function changeStatus(id, status) {
            $.ajax({
                url: '/accountant/taxes/' + id + '/status',
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    status: status
                },
                success: function(response) {
                    $('#tax-'+id).replaceWith(response);
                    Swal.fire({
                        icon: 'success',
                        text: 'tax status has been updated successfully!',
                    });
                },
                error: function(xhr) {
                    Swal.fire({
                        icon: 'error',
                        text: 'Something went wrong. Please try again.',
                    });
                }
            });
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('accountant.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\MyProjects\StripeInvoicePro\resources\views/accountant/taxes/index.blade.php ENDPATH**/ ?>