<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('transactions-page','active'); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Start Page-content -->
    <div class="page-content">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="ml-3"><b><?php echo e($title); ?></b></h4>
            </div>

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-card">
                                <table id="DataTables_Table_0" class="table nowrap dt-responsive align-middle table-hover table-bordered mb-0 dataTable no-footer dtr-inline collapsed">
                                    <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Transaction ID</th>
                                        <th>Invoice Number</th>
                                        <th>Customer</th>
                                        <th>Amount Paid</th>
                                        <th>Payment Date</th>
                                        <th>Items</th>
                                    </tr>
                                    </thead>
                                    <?php $i = 1; ?>
                                    <tbody id="transactions-report-table-body">
                                    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $invoice_paid_date = $invoice->invoice_paid_date;
                                            $invoice_paid_time = $invoice->invoice_paid_time;
                                            $invoice_paid_date = \DateTime::createFromFormat('Y-m-d', $invoice_paid_date);
                                            $invoice_paid_time = \DateTime::createFromFormat('H:i:s', $invoice_paid_time);
                                            $paid_date_time = $invoice_paid_date ? $invoice_paid_date->format('d M Y') . ' ' . $invoice_paid_time->format('g:i A') : 'N/A';
                                        ?>
                                        <tr id="transaction-<?php echo e($invoice->id); ?>">
                                            <td><?php echo e($i++); ?></td>
                                            <td>
                                                <a href="javascript:void(0);" class="text-body align-middle fw-medium"><?php echo e($invoice->charge_id ?? 'N/A'); ?></a>
                                            </td>
                                            <td><?php echo e($invoice->stripe_invoice_number); ?></td>
                                            <td>
                                                <?php echo e($invoice->customer->first_name . ' ' . $invoice->customer->last_name ?? 'N/A'); ?>

                                                <br>
                                                <?php echo e($invoice->customer->phone); ?>

                                                <span class="badge text-bg-warning p-1">
                                                    (<?php echo e($invoice->customer->country->iso_code); ?>)
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge text-bg-success p-1">
                                                    <?php echo e(App\Helpers\AppHelper::appCurrencySign()); ?><?php echo e(number_format($invoice->amount, 2)); ?>

                                                </span>
                                            </td>
                                            <td><?php echo e($paid_date_time); ?></td>
                                            <td>
                                                <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div>
                                                        <b><?php echo e($item->product->name); ?></b>
                                                        (<?php echo e($item->product_quantity); ?> x <?php echo e(App\Helpers\AppHelper::appCurrencySign()); ?><?php echo e(number_format($item->product_amount, 2)); ?>)
                                                        = <?php echo e(App\Helpers\AppHelper::appCurrencySign()); ?><?php echo e(number_format($item->product_quantity * $item->product_amount, 2)); ?>

                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\MyProjects\StripeInvoicePro\resources\views/admin/invoices/transactions.blade.php ENDPATH**/ ?>