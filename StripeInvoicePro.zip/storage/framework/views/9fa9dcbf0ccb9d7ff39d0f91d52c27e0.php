<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <div class="page-title">
                <div class="row">
                    <div class="col-12 col-sm-6">
                        <h3>Profile Setting</h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">

                            <form  action="<?php echo e(route('profile.update')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                                    <div class="row">
                                        <div class="col-lg-6 col-sm-12 mb-3">
                                            <label for="first_name" class="form-label">First Name <span class="required">*</span></label>
                                            <input type="text" id="first_name" class="form-control" name="first_name" value="<?php echo e($user->first_name); ?>">
                                        </div>
                                        <div class="col-lg-6 col-sm-12 mb-3">
                                            <label for="last_name" class="form-label">Last Name <span class="required">*</span></label>
                                            <input type="text" id="last_name" class="form-control" name="last_name" value="<?php echo e($user->last_name); ?>">
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-6 col-sm-12 mb-3">
                                            <label for="email" class="form-label">Email <span class="required">*</span></label>
                                            <input type="text" id="email" class="form-control" name="email" value="<?php echo e($user->email); ?>">
                                        </div>

                                        <div class="col-lg-6 col-sm-12 mb-3">
                                            <label for="phone" class="form-label">Phone <span class="required">*</span></label>
                                            <input type="text" id="phone" class="form-control" name="phone" value="<?php echo e($user->phone); ?>">
                                        </div>

                                        <div class="col-lg-12 col-sm-12 mb-3">
                                            <label for="address" class="form-label">Address <span class="required">*</span></label>
                                            <input type="text" id="address" class="form-control" name="billing_address" value="<?php echo e($user->billing_address); ?>">
                                        </div>

                                      </div>

                                    <div class="row">
                                        <div class="col-lg-6 col-sm-12 mb-3">
                                            <label for="password" class="form-label">Password <span class="required">*</span></label>
                                            <input type="password" id="password" class="form-control" name="password" placeholder="Enter Password">
                                        </div>
                                        <div class="col-lg-6 col-sm-12 mb-3">
                                            <label for="password_confirmation" class="form-label">Confirm Password <span class="required">*</span></label>
                                            <input type="password" id="password_confirmation" class="form-control" name="password_confirmation" placeholder="Confirm Password">
                                        </div>
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <div class="hstack gap-2 justify-content-end">
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                </div>
                            </form>


                        </div>
                    </div>
                    <!-- end col -->
                </div>
                <!-- end col -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        var forms = document.querySelectorAll('form');
        forms.forEach(function(form) {
            form.addEventListener('submit', function(event) {
                event.preventDefault();
                var submitButton = form.querySelector('button[type="submit"]');
                var originalText = submitButton.innerText; // Store the original text
                var $button = $(submitButton);
                $($button).html(`
                    <span class="text-light">processing...</span>
                    <span class="text-end text-light spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>`
                );
                submitButton.disabled = true;
                setTimeout(function() {
                    form.submit();
                }, 1000);
                setTimeout(function() {
                    $($button).html(originalText);
                    submitButton.disabled = false;
                }, 3000);
            });
        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('customer.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\MyProjects\StripeInvoicePro\resources\views/customer/profile.blade.php ENDPATH**/ ?>