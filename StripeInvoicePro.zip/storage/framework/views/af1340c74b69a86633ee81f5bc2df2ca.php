<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('invoices-dropdown','active'); ?>
<?php $__env->startSection('invoices-dropdown-show','show'); ?>
<?php $__env->startSection('all-invoices-list-page','active'); ?>
<?php $__env->startSection('all-invoices-list-page','active'); ?>
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Start Page-content -->
    <div class="page-content">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="ml-3"><b><?php echo e($title); ?></b></h4>
                <a href="<?php echo e(route('admin.invoices.create')); ?>" class="btn btn-primary">Create New</a>
            </div>
            <div class="row">
                <div class="col-xl-3 col-md-6">
                    <!-- Invoice Sent card -->
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-grow-1">
                                    <h4 class="fs-22 fw-semibold ff-secondary mb-2">
                                        <?php echo e(App\Helpers\AppHelper::appCurrencySign()); ?><span  data-target="<?php echo e(number_format($totalSentAmount, 2)); ?>"><?php echo e(number_format($totalSentAmount, 2)); ?></span>
                                    </h4>
                                    <p class="text-uppercase fw-medium fs-14 text-muted mb-0">
                                        Invoice Sent Sum
                                    </p>
                                </div>
                                <div class="avatar-sm flex-shrink-0">
                                <span class="avatar-title bg-light rounded-circle fs-3">
                                    <i class="las la-file-alt fs-24 text-primary"></i>
                                </span>
                                </div>
                            </div>
                            <div class="d-flex align-items-end justify-content-between mt-4">
                                <div>
                                    <span class="badge bg-primary me-1"><?php echo e($totalSentCount); ?></span> <span
                                        class="text-muted">Invoice Sent</span>
                                </div>
                            </div>
                        </div><!-- end card body -->
                    </div><!-- end card -->
                </div><!-- end col -->

                <div class="col-xl-3 col-md-6">
                    <!-- Paid Invoice card -->
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-grow-1">
                                    <h4 class="fs-22 fw-semibold ff-secondary mb-2">
                                        <?php echo e(App\Helpers\AppHelper::appCurrencySign()); ?> <span  data-target="<?php echo e(number_format($totalPaidAmount, 2)); ?>"><?php echo e(number_format($totalPaidAmount, 2)); ?></span>
                                    </h4>
                                    <p class="text-uppercase fw-medium fs-14 text-muted mb-0">
                                        Paid Invoice Sum
                                    </p>
                                </div>
                                <div class="avatar-sm flex-shrink-0">
                                <span class="avatar-title bg-light rounded-circle fs-3">
                                    <i class="las la-check-square fs-24 text-primary"></i>
                                </span>
                                </div>
                            </div>
                            <div class="d-flex align-items-end justify-content-between mt-4">
                                <div>
                                    <span class="badge bg-primary me-1"><?php echo e($totalPaidCount); ?></span> <span
                                        class="text-muted">Paid by clients</span>
                                </div>
                            </div>
                        </div><!-- end card body -->
                    </div><!-- end card -->
                </div><!-- end col -->

                <div class="col-xl-3 col-md-6">
                    <!-- Unpaid Invoice card -->
                    <div class="card bg-primary">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-grow-1">
                                    <h4 class="fs-22 fw-semibold ff-secondary mb-2 text-white">
                                        <?php echo e(App\Helpers\AppHelper::appCurrencySign()); ?><span  data-target="<?php echo e(number_format($totalUnpaidAmount, 2)); ?>"><?php echo e(number_format($totalUnpaidAmount, 2)); ?></span>
                                    </h4>
                                    <p class="text-uppercase fw-medium fs-14 text-white-50 mb-0">
                                        Unpaid Invoice Sum
                                    </p>
                                </div>
                                <div class="avatar-sm flex-shrink-0">
                                <span class="avatar-title bg-soft-light rounded-circle fs-3">
                                    <i class="las la-clock fs-24 text-white"></i>
                                </span>
                                </div>
                            </div>
                            <div class="d-flex align-items-end justify-content-between mt-4">
                                <div>
                                    <span class="badge bg-danger me-1"><?php echo e($totalUnpaidCount); ?></span> <span
                                        class="text-white">Unpaid by clients</span>
                                </div>
                            </div>
                        </div><!-- end card body -->
                    </div><!-- end card -->
                </div><!-- end col -->

                <div class="col-xl-3 col-md-6">
                    <!-- Cancelled Invoices card -->
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-grow-1">
                                    <h4 class="fs-22 fw-semibold ff-secondary mb-2">
                                        <?php echo e(App\Helpers\AppHelper::appCurrencySign()); ?><span  data-target="<?php echo e(number_format($totalCancelledAmount, 2)); ?>"><?php echo e(number_format($totalCancelledAmount, 2)); ?></span>
                                    </h4>
                                    <p class="text-uppercase fw-medium fs-14 text-muted mb-0">
                                        Cancelled Invoices
                                    </p>
                                </div>
                                <div class="avatar-sm flex-shrink-0">
                                <span class="avatar-title bg-light rounded-circle fs-3">
                                    <i class="las la-times-circle fs-24 text-primary"></i>
                                </span>
                                </div>
                            </div>
                            <div class="d-flex align-items-end justify-content-between mt-4">
                                <div>
                                    <span class="badge bg-primary me-1"><?php echo e($totalCancelledCount); ?></span> <span
                                        class="text-muted">Cancelled Invoices</span>
                                </div>
                            </div>
                        </div><!-- end card body -->
                    </div><!-- end card -->
                </div><!-- end col -->
            </div><!-- end row -->
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-tabs nav-tabs-custom nav-success mb-3" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link <?php echo $__env->yieldContent('all-invoices-list-page'); ?>"
                                       href="<?php echo e(url('/admin/invoices')); ?>" role="tab" aria-selected="true">
                                        All
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link <?php echo $__env->yieldContent('unpaid-invoices-list-page'); ?>"
                                       href="<?php echo e(url('/admin/invoices/unpaid')); ?>" role="tab" aria-selected="false">
                                        UnPaid
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo $__env->yieldContent('paid-invoices-list-page'); ?>"
                                       href="<?php echo e(url('/admin/invoices/paid')); ?>" role="tab" aria-selected="false">
                                        Paid
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link <?php echo $__env->yieldContent('void-invoices-list-page'); ?>"
                                       href="<?php echo e(url('/admin/invoices/void')); ?>" role="tab" aria-selected="false">
                                        Void
                                    </a>
                                </li>

                            </ul>

                            <div class="table-card">
                                <table id="DataTables_Table_0"
                                       class="table nowrap dt-responsive align-middle table-hover table-bordered mb-0 dataTable no-footer dtr-inline collapsed">
                                    <thead class="table-light">
                                    <tr>
                                        <th>Invoice Number</th>
                                        <th>Customer</th>
                                        <th>Amount Due</th>
                                        <th>Created At</th>
                                        <th>Due Date</th>
                                        <th>Payment Link</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody id="invoice-table-body">
                                    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="invoice-<?php echo e($invoice->id); ?>">
                                            <td>
                                                <a href="<?php echo e(route('admin.invoices.show', $invoice->id)); ?>"
                                                   class="text-body align-middle fw-medium"><?php echo e($invoice->stripe_invoice_number); ?></a>
                                            </td>
                                            <td>
                                                <?php echo e($invoice->customer->first_name. ' ' .$invoice->customer->last_name ?? 'N/A'); ?>

                                                <br>
                                                <?php echo e($invoice->customer->phone); ?>

                                                <span class="badge text-bg-warning ">
                                                (<?php echo e($invoice->customer->country->iso_code); ?>)
                                            </span>

                                            </td>
                                            <td>
                                            <span class="badge text-bg-dark">
                                                <?php echo e(App\Helpers\AppHelper::appCurrencySign()); ?><?php echo e(number_format($invoice->amount, 2)); ?>

                                            </span>
                                            </td>
                                            <td><?php echo e($invoice->created_at->format('d M Y')); ?></td>
                                            <td><?php echo e(date('d M Y',strtotime($invoice->period_end ))); ?></td>

                                            <td>
                                                <?php if($invoice->status != 'void'): ?>
                                                    <span style="cursor: pointer;"
                                                          class="badge badge-soft-primary sharePaymentLink"
                                                          data-link="<?php echo e($invoice->stripe_invoice_url); ?>">Copy Now</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                        <span
                                            class="badge  <?php echo e($invoice->status === 'paid' ? 'badge-soft-success' : 'badge-soft-info'); ?>">
                                            <?php echo e(ucfirst($invoice->status)); ?>

                                        </span>
                                            </td>
                                            <td>
                                                <a class="btn btn-soft-info btn-sm"
                                                   href="<?php echo e(route('admin.invoices.show', $invoice->id)); ?>">
                                                    <i class="las la-eye fs-17 align-middle"></i>
                                                </a>

                                                
                                                
                                                
                                                
                                                

                                                <a href="<?php echo e($invoice->stripe_invoice_pdf_url); ?>"
                                                   class="btn btn-soft-warning btn-sm">
                                                    <i class="la la-download fs-17 align-middle"></i>
                                                </a>

                                                <?php if($invoice->status != 'paid' || $invoice->status != 'void'): ?>
                                                    <button class="btn btn-soft-danger btn-sm"
                                                            onclick="voidInvoice(<?php echo e($invoice->id); ?>)">
                                                        <i class="las la-trash fs-17 align-middle"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>

        function voidInvoice(invoiceId) {
            Swal.fire({
                title: 'Are you sure?',
                text: "Are you sure you want to void this invoice? Once voided, the customer will no longer be able to make payments on this invoice. This action cannot be undone.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, void it!',
                cancelButtonText: 'Cancel',
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: "/admin/invoices/make-void/" + invoiceId,
                        type: 'GET',
                        data: {
                            "_token": "<?php echo e(csrf_token()); ?>"
                        },
                        success: function (response) {
                            Swal.fire({
                                icon: 'success',
                                text: response.message,
                                confirmButtonText: 'OK'
                            }).then(() => {
                                window.location.href = `/admin/invoices`;
                            });
                        },
                        error: function () {
                            Swal.fire({
                                icon: 'error',
                                text: 'Something went wrong. Please try again.',
                            });
                        }
                    });
                }
            });
        }


        var shareButtons = document.getElementsByClassName('sharePaymentLink');
        for (var i = 0; i < shareButtons.length; i++) {
            shareButtons[i].addEventListener('click', function () {
                var currentUrl = this.getAttribute('data-link');
                var tempInput = document.createElement('input');
                tempInput.setAttribute('type', 'text');
                tempInput.setAttribute('value', currentUrl);
                document.body.appendChild(tempInput);
                tempInput.select();
                document.execCommand('copy');
                document.body.removeChild(tempInput);
                this.innerText = 'Copied!';
                var that = this;
                setTimeout(function () {
                    that.innerText = 'Copy Now';
                }, 1000);
            });
        }
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\MyProjects\StripeInvoicePro\resources\views/admin/invoices/index.blade.php ENDPATH**/ ?>